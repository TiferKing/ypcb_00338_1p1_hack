/******************************************************************************
* Copyright (c) 2021 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
 ******************************************************************************/

#include <stdio.h>
#include "xparameters.h"
#include "xil_types.h"
#include "xstatus.h"
#include "xil_testmem.h"

#include "platform.h"
#include "memory_config.h"
#include "xil_printf.h"
#include "xgpio.h"
#include "xiic.h"
#include "xintc.h"
#include "xil_exception.h"

/*
 * memory_test.c: Test memory ranges present in the Hardware Design.
 *
 * This application runs with D-Caches disabled. As a result cacheline requests
 * will not be generated.
 *
 * For MicroBlaze/PowerPC, the BSP doesn't enable caches and this application
 * enables only I-Caches. For ARM, the BSP enables caches by default, so this
 * application disables D-Caches before running memory tests.
 */

void putnum(unsigned int num);

void test_memory_range(struct memory_range_s *range) {
    XStatus status;

    /* This application uses print statements instead of xil_printf/printf
     * to reduce the text size.
     *
     * The default linker script generated for this application does not have
     * heap memory allocated. This implies that this program cannot use any
     * routines that allocate memory on heap (printf is one such function).
     * If you'd like to add such functions, then please generate a linker script
     * that does allocate sufficient heap memory.
     */

    print("Testing memory region: "); print(range->name);  print("\n\r");
    print("    Memory Controller: "); print(range->ip);  print("\n\r");
    #if defined(__MICROBLAZE__) && !defined(__arch64__)
        #if (XPAR_MICROBLAZE_ADDR_SIZE > 32)
            print("         Base Address: 0x"); putnum((range->base & UPPER_4BYTES_MASK) >> 32); putnum(range->base & LOWER_4BYTES_MASK);print("\n\r");
        #else
            print("         Base Address: 0x"); putnum(range->base); print("\n\r");
        #endif
        print("                 Size: 0x"); putnum(range->size); print (" bytes \n\r");
    #else
        xil_printf("         Base Address: 0x%lx \n\r",range->base);
        xil_printf("                 Size: 0x%lx bytes \n\r",range->size);
    #endif

#if defined(__MICROBLAZE__) && !defined(__arch64__) && (XPAR_MICROBLAZE_ADDR_SIZE > 32)
    status = Xil_TestMem32((range->base & LOWER_4BYTES_MASK), ((range->base & UPPER_4BYTES_MASK) >> 32), 1024, 0xAAAA5555, XIL_TESTMEM_ALLMEMTESTS);
    print("          32-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem16((range->base & LOWER_4BYTES_MASK), ((range->base & UPPER_4BYTES_MASK) >> 32), 2048, 0xAA55, XIL_TESTMEM_ALLMEMTESTS);
    print("          16-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem8((range->base & LOWER_4BYTES_MASK), ((range->base & UPPER_4BYTES_MASK) >> 32), 4096, 0xA5, XIL_TESTMEM_ALLMEMTESTS);
    print("           8-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");
#else
    status = Xil_TestMem32((u32*)range->base, 1024, 0xAAAA5555, XIL_TESTMEM_ALLMEMTESTS);
    print("          32-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem16((u16*)range->base, 2048, 0xAA55, XIL_TESTMEM_ALLMEMTESTS);
    print("          16-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = Xil_TestMem8((u8*)range->base, 4096, 0xA5, XIL_TESTMEM_ALLMEMTESTS);
    print("           8-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");
#endif

}

////////////////////GPIO
#define GPIO_LED XPAR_GPIO_0_DEVICE_ID
XGpio GpioLed;
#define LED_CH 1
#define LED_R 0x01
#define LED_G 0x02
#define LED_Y 0x04
int GPIO_Init(void);

////////////////////IIC LM73
#define IIC_ADDR	0x4A
#define IIC_ID		XPAR_IIC_0_DEVICE_ID
#define INTC_ID		XPAR_INTC_0_DEVICE_ID
#define INT_IIC_ID	XPAR_INTC_0_IIC_0_VEC_ID

XIic IicLM73;
XIntc InterruptController;

int IIC_Init(void);
static void RecvHandler(void *CallbackRef, int ByteCount);
static void StatusHandler(void *CallbackRef, int Status);
volatile u16 Temperature;
volatile u8 SensorDone, SensorError;
volatile u8 TemperaturePtr[2];

int main()
{
    sint32 i;
    int Status;
    char key;
    u8 led = 0;

    init_platform();
    Status = GPIO_Init();
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    Status = IIC_Init();
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	print("Press 'r','g','y' to toggle LEDs. Press 'm' to run memory test. 't' to get temperature.\n\r");
    while(1)
    {
		key = XUartLite_RecvByte(XPAR_UARTLITE_0_BASEADDR);
		switch(key)
		{
		case 'r':
			led ^= LED_R;
			XGpio_DiscreteWrite(&GpioLed, LED_CH, led);
			break;
		case 'g':
			led ^= LED_G;
			XGpio_DiscreteWrite(&GpioLed, LED_CH, led);
			break;
		case 'y':
			led ^= LED_Y;
			XGpio_DiscreteWrite(&GpioLed, LED_CH, led);
			break;
		case 'm':
			print("--Starting Memory Test Application--\n\r");
			print("NOTE: This application runs with D-Cache disabled.");
			print("As a result, cacheline requests will not be generated\n\r");

			for (i = 0; i < n_memory_ranges; i++) {
				test_memory_range(&memory_ranges[i]);
			}

			print("--Memory Test Application Complete--\n\r");
			print("Successfully ran Memory Test Application.\n\r");
			break;
		case 't':
			SensorDone = 0;
			SensorError = 0;
			XIic_MasterRecv(&IicLM73, (u8 *)TemperaturePtr, 2);
			while(!(SensorDone || SensorError)) {};
			if(SensorError) {
				xil_printf("Temperature Sensor Error.\r\n");
			} else {
				Temperature = TemperaturePtr[0] << 8;
				Temperature += TemperaturePtr[1];
				xil_printf("Temperature: %d.%dC\r\n", Temperature / 128, (Temperature * 100 / 128) % 100);
			}
			break;
		}
    }
    cleanup_platform();
    return 0;
}

int GPIO_Init(void)
{
	int Status;
	Status = XGpio_Initialize(&GpioLed, GPIO_LED);
	if (Status != XST_SUCCESS) {
		xil_printf("Gpio Initialization Failed\r\n");
		return XST_FAILURE;
	}

	XGpio_SetDataDirection(&GpioLed, LED_CH, 0x0);
	XGpio_DiscreteWrite(&GpioLed, LED_CH, 0x0);
	return XST_SUCCESS;
}

int IIC_Init(void)
{
	int Status;
	static int Initialized = FALSE;
	XIic_Config *ConfigPtr;	/* Pointer to configuration data */

	if (!Initialized) {
		Initialized = TRUE;

		ConfigPtr = XIic_LookupConfig(IIC_ID);
		if (ConfigPtr == NULL) {
			return XST_FAILURE;
		}

		Status = XIic_CfgInitialize(&IicLM73, ConfigPtr, ConfigPtr->BaseAddress);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		XIic_SetRecvHandler(&IicLM73, NULL, RecvHandler);
		XIic_SetStatusHandler(&IicLM73, NULL, StatusHandler);

		Status = XIntc_Initialize(&InterruptController, INTC_ID);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = XIntc_Connect(&InterruptController, INT_IIC_ID, XIic_InterruptHandler, &IicLM73);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = XIntc_Start(&InterruptController, XIN_REAL_MODE);
		if (Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		XIntc_Enable(&InterruptController, INT_IIC_ID);

		Xil_ExceptionInit();

		Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler) XIntc_InterruptHandler, &InterruptController);

		Xil_ExceptionEnable();

		XIic_Start(&IicLM73);
		XIic_SetAddress(&IicLM73, XII_ADDR_TO_SEND_TYPE, IIC_ADDR);
	}
	return XST_SUCCESS;
}

static void RecvHandler(void *CallbackRef, int ByteCount)
{
	if(ByteCount == 0)
	{
		SensorDone = 1;
	}
}

static void StatusHandler(void *CallbackRef, int Status)
{
	SensorError = 1;
}
